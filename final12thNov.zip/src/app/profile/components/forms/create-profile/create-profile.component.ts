import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Profile } from 'src/app/profile/models/profile';
import { ProfileService } from 'src/app/profile/service/profile.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  // this profile form we will use it for creating/ updating the profile.

  profile: Profile = new Profile();
  error: any = {};
  constructor(private profileService: ProfileService, private router: Router) {}

  ngOnInit(): void {
    // @ the time of loading the profile form then thecontets should be loaded.
  }

  createProfileSubmit() {
    this.profileService.createProfile(this.profile).subscribe(
      (res) => {
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        //this.error = err;
        console.log(JSON.stringify(err));
      }
    );
  }
}
