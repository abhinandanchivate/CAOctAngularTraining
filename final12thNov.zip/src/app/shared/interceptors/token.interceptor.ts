import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // header : authorization : add the token
    // how to get the token? ==> after login ==> we will get the token
    // login, register like that : for them we will not add the token .
    //(public end points)
    // token interceptor will work for only private end points.
    // common public end points : can we hold it in the array ?
    // can we cross check it with coming url?

    if (request.url.includes('login') || request.url.includes('register')) {
      console.log('hello from token interceptor if condition is true');
      return next.handle(request);
    }

    let token = localStorage.getItem('token');
    if (token) {
      console.log('inside the token interceptor');
      let req = request.clone({
        headers: request.headers.set('x-auth-token', token),
      });
      console.log(JSON.stringify(req));
      return next.handle(req);
    }
    return next.handle(request);
  }
}
