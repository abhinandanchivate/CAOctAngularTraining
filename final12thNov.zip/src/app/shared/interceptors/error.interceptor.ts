import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((err) => {
        console.log(JSON.stringify(err.error.errors));
        let temp: any = {};
        err.error.errors.forEach((e: any) => {
          console.log(e.msg);
          // param : msg

          temp[`${e.param}`] = e.msg;
          // {}
          //errorMsg.push(temp);
        });

        console.log(JSON.stringify(temp));
        return throwError(temp);
      })
    );
  }
}
