export class Register {
  // it will hold the data till performing the rest call for register.

  name: string;
  email: string;
  password: string;
  password2: string;
}
