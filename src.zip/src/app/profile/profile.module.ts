import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { AddEduComponent } from './components/forms/add-edu/add-edu.component';
import { AddExpComponent } from './components/forms/add-exp/add-exp.component';
import { CreateProfileComponent } from './components/forms/create-profile/create-profile.component';
import { DisplayProfileComponent } from './components/pages/display-profile/display-profile.component';
import { ProfileTopComponent } from './components/pages/display-profile/profile-top/profile-top.component';
import { ProfileAboutComponent } from './components/pages/display-profile/profile-about/profile-about.component';
import { ProfileExperienceComponent } from './components/pages/display-profile/profile-experience/profile-experience.component';
import { ProfileGithubComponent } from './components/pages/display-profile/profile-github/profile-github.component';
import { ProfileEducationComponent } from './components/pages/display-profile/profile-education/profile-education.component';
import { DisplayProfilesComponent } from './components/pages/display-profiles/display-profiles.component';
import { ProfileItemComponent } from './components/pages/display-profiles/profile-item/profile-item.component';
import { ProfileService } from './services/profile.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { httpInterceptor } from '../shared/interceptors';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AddEduComponent,
    AddExpComponent,
    CreateProfileComponent,
    DisplayProfileComponent,
    ProfileTopComponent,
    ProfileAboutComponent,
    ProfileExperienceComponent,
    ProfileGithubComponent,
    ProfileEducationComponent,
    DisplayProfilesComponent,
    ProfileItemComponent,
  ],
  imports: [CommonModule, HttpClientModule, FormsModule, ProfileRoutingModule],
  providers: [ProfileService, HttpClient, httpInterceptor],
})
export class ProfileModule {}
