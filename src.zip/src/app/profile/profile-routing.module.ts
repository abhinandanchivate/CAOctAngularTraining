import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEduComponent } from './components/forms/add-edu/add-edu.component';
import { AddExpComponent } from './components/forms/add-exp/add-exp.component';
import { CreateProfileComponent } from './components/forms/create-profile/create-profile.component';
import { DisplayProfileComponent } from './components/pages/display-profile/display-profile.component';
import { DisplayProfilesComponent } from './components/pages/display-profiles/display-profiles.component';

const routes: Routes = [
  {
    path: 'add-edu',
    component: AddEduComponent,
  },
  {
    path: 'add-exp',
    component: AddExpComponent,
  },
  {
    path: 'create-profile',
    component: CreateProfileComponent,
  },
  {
    path: 'display-profile',
    component: DisplayProfileComponent,
  },
  {
    path: 'display-profiles',
    component: DisplayProfilesComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfileRoutingModule {}
