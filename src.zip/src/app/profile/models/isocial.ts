export interface ISocial {
  twitter: string;
  facebook: string;
  linkedin: string;
  youtube: string;
  instagram: string;
}
