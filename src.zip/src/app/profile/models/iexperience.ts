export interface IExperience {
  title: string;
  company: string;
  location: string;
  from: string;
  to: string;
  current: boolean;
  _id: any;
}
