import { IExperience } from './iexperience';
import { ISocial } from './isocial';

export interface IProfile {
  handle: string;
  status: string;
  company: string;
  website: string;
  location: string;
  skills: string;
  githubusername: string;
  bio: string;
  social: ISocial;
  experience: [];
  education: [];
}
