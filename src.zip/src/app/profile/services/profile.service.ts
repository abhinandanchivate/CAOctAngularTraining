import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IEducation } from '../models/ieducation';
import { IExperience } from '../models/iexperience';
import { IProfile } from '../models/iprofile';

@Injectable({
  providedIn: 'root',
})
export class ProfileService {
  constructor(private httpClient: HttpClient) {}

  getCurrentProfile(): Observable<any> {
    return this.httpClient.get('/api/profile/me');
  }

  createProfile(data: IProfile): Observable<any> {
    return this.httpClient.post<any>('/api/profile', data);
  }

  addExp(data: IExperience): Observable<any> {
    return this.httpClient.put('/api/profile/experience', data);
  }
  addEdu(data: IEducation): Observable<any> {
    return this.httpClient.put('/api/profile/education', data);
  }

  deleteExperience(id: string): Observable<any> {
    return this.httpClient.delete('/api/profile/experience/' + id);
  }
}
