import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IExperience } from 'src/app/profile/models/iexperience';
import { ProfileService } from 'src/app/profile/services/profile.service';

@Component({
  selector: 'app-add-exp',
  templateUrl: './add-exp.component.html',
  styleUrls: ['./add-exp.component.css'],
})
export class AddExpComponent implements OnInit {
  exp: IExperience = {
    title: '',
    company: '',
    location: '',
    from: '',
    to: '',
    current: false,
    _id: null,
  };
  constructor(private profileService: ProfileService, private router: Router) {}

  ngOnInit(): void {}

  submitExp() {
    this.profileService.addExp(this.exp).subscribe(
      (res) => {
        console.log('Experience added successfully');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
