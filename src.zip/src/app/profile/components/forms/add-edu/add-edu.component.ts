import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IEducation } from 'src/app/profile/models/ieducation';
import { ProfileService } from 'src/app/profile/services/profile.service';

@Component({
  selector: 'app-add-edu',
  templateUrl: './add-edu.component.html',
  styleUrls: ['./add-edu.component.css'],
})
export class AddEduComponent implements OnInit {
  edu: IEducation = {
    school: '',
    degree: '',
    fieldofstudy: '',
    from: '',
    to: '',
    current: false,
    description: '',
  };
  constructor(private profileService: ProfileService, private router: Router) {}

  ngOnInit(): void {}

  submitEdu() {
    this.profileService.addEdu(this.edu).subscribe(
      (res) => {
        console.log('Education added successfully');
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
