import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProfile } from 'src/app/profile/models/iprofile';
import { ISocial } from 'src/app/profile/models/isocial';
import { ProfileService } from 'src/app/profile/services/profile.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  error: any = {};
  profile: IProfile = {
    handle: '',
    status: '',
    company: '',
    website: '',
    location: '',
    skills: '',
    githubusername: '',
    bio: '',
    experience: [],
    education: [],
    social: {
      twitter: '',
      facebook: '',
      linkedin: '',
      youtube: '',
      instagram: '',
    },
  };
  // social: ISocial = {
  //   twitter: '',
  //   facebook: '',
  //   linkedin: '',
  //   youtube: '',
  //   instagram: '',
  // };
  constructor(private profileService: ProfileService, private router: Router) {}
  currProfile: any = null;
  ngOnInit(): void {
    this.profileService.getCurrentProfile().subscribe(
      (res) => {
        console.log(res);
        this.profile = res;
        // this.profile.social = res.social;
        this.currProfile = res;
      },
      (err) => {}
    );
  }

  createProfileSubmit() {
    this.profileService.createProfile(this.profile).subscribe(
      (res) => {
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }
}
