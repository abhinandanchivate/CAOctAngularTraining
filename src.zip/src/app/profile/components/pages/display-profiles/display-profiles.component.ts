import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-profiles',
  templateUrl: './display-profiles.component.html',
  styleUrls: ['./display-profiles.component.css']
})
export class DisplayProfilesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
