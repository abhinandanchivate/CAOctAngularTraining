import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HeadersInterceptor } from './headers.interceptor';
import { TokenInterceptor } from './token.interceptor';

export const httpInterceptor = [
  // {
  //   provide: HTTP_INTERCEPTORS,
  //   useClass: HeadersInterceptor,
  //   multi: true,
  // },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi: true,
  },
];

//  all interceotors are services
// http interceptors are the interfaces
