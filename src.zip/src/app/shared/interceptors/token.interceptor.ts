import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/users/services/auth.service';
import { endPoints } from 'src/app/utils/constants';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // let token: string = localStorage.getItem('token') || '';

    let token = localStorage.getItem('token');

    console.log(request.url);
    console.log(request.method);

    // endPoints.forEach((end) => {
    //   if (request.url === end.endPoint && request.method === end.method) {
    //     console.log('inside post criter');
    //     return next.handle(request);
    //   }
    //   if (token) {
    //     request = request.clone({
    //       headers: request.headers.set('x-auth-token', token),
    //     });
    //     return next.handle(request);
    //   }
    //   return next.handle(request);
    // });

    // if (request.url == '/users/auth' && request.method === 'POST') {
    //   console.log('inside post criter');
    //   return next.handle(request);
    // }
    console.log(token);
    if (token) {
      console.log('token avail');
      request = request.clone({
        headers: request.headers.set('x-auth-token', token),
      });
      return next.handle(request);
    }
    return next.handle(request);
  }
}
