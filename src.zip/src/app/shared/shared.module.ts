import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { httpInterceptor } from './interceptors';
import { RefreshService } from './services/refresh.service';

@NgModule({
  declarations: [],
  imports: [CommonModule],
  providers: [httpInterceptor, RefreshService],
})
export class SharedModule {}
