import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RefreshService } from 'src/app/shared/services/refresh.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent implements OnInit {
  constructor(private router: Router, private refreshService: RefreshService) {}

  token: any;
  flag: boolean = false;
  ngOnInit(): void {
    this.token = localStorage.getItem('token');
    this.refreshService.refreshSubject.subscribe(
      (res) => {
        this.flag = res;
      },
      (err) => {
        this.flag = false;
      }
    );
  }

  logout() {
    console.log('button clicked');
    //localStorage.removeItem('token');
    localStorage.clear();
    this.refreshService.refreshSubject.next(false);
    this.router.navigate(['']);
  }
}
