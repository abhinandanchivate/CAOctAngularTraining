export const endPoints = [
  { endPoint: '/api/auth', method: 'POST' },
  { endPoint: '/api/users', method: 'POST' },
];
