import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardActionComponent } from './components/dashboard-action/dashboard-action.component';
import { DashboardDisplayExpComponent } from './components/dashboard-display-exp/dashboard-display-exp.component';
import { DashboardDisplayEduComponent } from './components/dashboard-display-edu/dashboard-display-edu.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ProfileService } from '../profile/services/profile.service';
import { httpInterceptor } from '../shared/interceptors';
import { AuthService } from '../users/services/auth.service';
import { FormsModule } from '@angular/forms';
import { ExpItemComponent } from './components/dashboard-display-exp/exp-item/exp-item.component';

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionComponent,
    DashboardDisplayExpComponent,
    DashboardDisplayEduComponent,
    ExpItemComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    DashboardRoutingModule,
  ],
  providers: [HttpClient, ProfileService, httpInterceptor, AuthService],
})
export class DashboardModule {}
