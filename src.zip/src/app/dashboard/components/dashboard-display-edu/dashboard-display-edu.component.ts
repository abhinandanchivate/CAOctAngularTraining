import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-display-edu',
  templateUrl: './dashboard-display-edu.component.html',
  styleUrls: ['./dashboard-display-edu.component.css']
})
export class DashboardDisplayEduComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
