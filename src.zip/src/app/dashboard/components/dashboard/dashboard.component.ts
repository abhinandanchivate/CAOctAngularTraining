import { Component, OnInit } from '@angular/core';
import { join } from 'path';
import { ProfileService } from 'src/app/profile/services/profile.service';
import { AuthService } from 'src/app/users/services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  profile: any = null;
  user: string = '';

  constructor(
    private profileService: ProfileService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.authService.getUserDetails().subscribe(
      (res) => {
        console.log(JSON.stringify(res));
        this.user = res.name;
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
    this.profileService.getCurrentProfile().subscribe(
      (res) => {
        console.log(res);
        this.profile = res;
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  deleteExperience(expId: string) {
    console.log('In Parent :::::' + expId);
    this.profileService.deleteExperience(expId).subscribe(
      (res) => {
        console.log('Response::', JSON.stringify(res));
        this.profile = res;
        // this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log('Error::::', JSON.stringify(err));
        this.profile = null;
      }
    );
  }
}
