import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IExperience } from 'src/app/profile/models/iexperience';

@Component({
  selector: 'app-dashboard-display-exp',
  templateUrl: './dashboard-display-exp.component.html',
  styleUrls: ['./dashboard-display-exp.component.css'],
})
export class DashboardDisplayExpComponent implements OnInit {
  @Output()
  expId: EventEmitter<string> = new EventEmitter();
  @Input()
  exp: IExperience[] = [];
  constructor() {}

  ngOnInit(): void {}

  deleteExp(expId: string) {
    console.log('expId value from display-exp: ' + expId);
    this.expId.emit(expId);
  }
}
