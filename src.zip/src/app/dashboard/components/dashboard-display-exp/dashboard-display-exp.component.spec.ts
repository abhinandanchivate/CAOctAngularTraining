import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardDisplayExpComponent } from './dashboard-display-exp.component';

describe('DashboardDisplayExpComponent', () => {
  let component: DashboardDisplayExpComponent;
  let fixture: ComponentFixture<DashboardDisplayExpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardDisplayExpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardDisplayExpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
