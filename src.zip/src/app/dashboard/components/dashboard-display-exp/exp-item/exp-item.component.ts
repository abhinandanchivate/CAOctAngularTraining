import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IExperience } from 'src/app/profile/models/iexperience';

@Component({
  selector: 'app-exp-item',
  templateUrl: './exp-item.component.html',
  styleUrls: ['./exp-item.component.css'],
})
export class ExpItemComponent {
  @Output()
  expId: EventEmitter<string> = new EventEmitter();
  @Input()
  e: IExperience = {
    _id: '',
    company: '',
    current: false,
    from: '',
    to: '',
    title: '',
    location: '',
  };

  deleteExp(id: string) {
    console.log('id value from exp-item: ' + id);
    this.expId.emit(id);
  }
}
