import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RefreshService } from 'src/app/shared/services/refresh.service';
import { ILogin } from 'src/app/users/models/ilogin';
import { AuthService } from 'src/app/users/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  constructor(
    private authService: AuthService,
    private router: Router,
    private refreshService: RefreshService
  ) {}

  login: ILogin = {
    email: '',
    password: '',
  };
  error: any = {};
  loginSubmit() {
    this.error = {};
    this.authService.loginUser(this.login).subscribe(
      (res) => {
        console.log(JSON.stringify(this.login));
        console.log('Login Sucess');
        this.refreshService.refreshSubject.next(true);
        this.router.navigate(['/dashboard/']);
      },
      (err) => {
        // console.log(err);

        err.error.errors.forEach((e: any) => {
          console.log(e.msg);
          this.error[e.param] = e.msg;
        });
      }
    );
  }
}
// /api/profile/me - help us to wherther the users profile are complete or not, for this we need token
// whether we want to manupulet the request and response objects use interceptor
