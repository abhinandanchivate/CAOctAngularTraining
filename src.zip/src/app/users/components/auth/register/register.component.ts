import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { IRegister } from 'src/app/users/models/iregister';
import { AuthService } from 'src/app/users/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  constructor(private authService: AuthService, private router: Router) {}

  error: any = {};

  register: IRegister = {
    confirmPassword: '',
    password: '',
    email: '',
    name: '',
  };

  registerSubmit() {
    console.log(JSON.stringify(this.register));

    this.authService.registerUser(this.register).subscribe(
      (res) => {
        console.log(JSON.stringify(res));
        localStorage.setItem('token', res.token);
        this.router.navigate(['/users/login']);
      },
      (err) => {
        // console.log(err);
        this.error = {};
        err.error.errors.forEach((e: any) => {
          console.log(JSON.stringify(e.msg));
          this.error[e.param] = e.msg;
        });
      }
    );
  }
}
