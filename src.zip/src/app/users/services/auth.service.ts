import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ILogin } from '../models/ilogin';
import { IRegister } from '../models/iregister';

const headers = { headers: { 'Content-Type': 'application/json' } };

// const authHeades = {
//   headers: { 'x-auth-token': localStorage.getItem('token') },
// };

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private httpClient: HttpClient) {}

  registerUser(register: IRegister): Observable<any> {
    return this.httpClient.post('/api/users', register, headers);
  }
  // /api/auth
  loginUser(login: ILogin): Observable<any> {
    return this.httpClient.post('/api/auth', login);
  }

  getUserDetails(): Observable<any> {
    console.log('inside getUserDetails');
    return this.httpClient.get('/api/auth/');
  }

  validateUser(): Observable<any> {
    return this.httpClient.get('/api/auth');
  }
}
